import oracle.jdbc.pool.OracleDataSource;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class App {
    Connection conn;

    public static void main(String[] args) {
        App app = new App();
        try {
            app.setConnection();
            if(args[0].equals("adresy_w_kraju")){
                app.showAddressesInCountry(Integer.parseInt(args[1]));
            } else if(args[0].equals("zmień_cenę_kwatery")){
                app.updatePrice(Integer.parseInt(args[1]), Integer.parseInt(args[2]));
            } else {
                System.out.println("Złe argumenty");
            }
            app.closeConnection();
        }
        catch (SQLException eSQL) {
            System.out.println("Blad przetwarzania SQL " + eSQL.getMessage());
        }
        catch (IOException eIO) {
            System.out.println("Nie mozna otworzyc pliku" );
        }
    }


    public void setConnection() throws SQLException, IOException {
        Properties properties = new Properties();
        FileInputStream in = new FileInputStream("connection.properties");
        properties.load(in);
        in.close();

        String host = properties.getProperty("jdbc.host");
        String username = properties.getProperty("jdbc.username");
        String password = properties.getProperty("jdbc.password");
        String port = properties.getProperty("jdbc.port");
        String serviceName = properties.getProperty("jdbc.service.name");

        String connectionString = String.format(
                "jdbc:oracle:thin:%s/%s@//%s:%s/%s",
                username, password, host, port, serviceName);

        System.out.println (connectionString);
        OracleDataSource ods;
        ods = new OracleDataSource();

        ods.setURL(connectionString);
        conn = ods.getConnection();

        DatabaseMetaData meta = conn.getMetaData();

        System.out.println("Polaczenie do bazy danych nawiązne.");
    }

    public void closeConnection() throws SQLException { // zamkniecie polaczenia
        conn.close();
        System.out.println("Polaczenie z baza zamkniete poprawnie.");
    }

    public void showAddressesInCountry(Integer id) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement("SELECT ulica, numer, kod_pocztowy, miejscowosc FROM adres WHERE id_kraju = " + id.toString());
        ResultSet rs = preparedStatement.executeQuery();
        System.out.println("---------------------------------");
        while (rs.next()) {
            System.out.println(rs.getString(1) + " " + rs.getString(2)  + " " + rs.getString(3)  + " " + rs.getString(4));
        }
        System.out.println("---------------------------------");
        rs.close();
        preparedStatement.close();
    }

    public void updatePrice(Integer id, Integer newPrice) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement("UPDATE typ_kwatery SET stawka_roczna = "
                + newPrice.toString() + " WHERE id_typu_kwatery = " + id.toString());
        preparedStatement.executeQuery();
        System.out.println("Cena została zmieniona");
    }
}
